
public class Testing
{

    public static void main(String[] args)
    {
//        Object obj;
//        Object[] objArray =
//        {
//            new Object(1,1,1,1,true)
//        };
//        
//        System.out.println(objArray[0]);
//        
//        System.out.println("--------------");
//        
//        obj = objArray[0];
//        
//        System.out.println(obj.getXCoor());

        
    }
}
